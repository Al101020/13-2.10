import './css/style.css';

import './js/app';

import './img/js.png';
import './img/netology.png';

// TODO: write your code in app.js